import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './component';
import * as ɵngcc2 from './directive';
export declare class AceEditorModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<AceEditorModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<AceEditorModule, [typeof ɵngcc1.AceEditorComponent, typeof ɵngcc2.AceEditorDirective], never, [typeof ɵngcc1.AceEditorComponent, typeof ɵngcc2.AceEditorDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<AceEditorModule>;
}

//# sourceMappingURL=module.d.ts.map