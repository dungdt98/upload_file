/**
 * Generated bundle index. Do not edit.
 */
export * from './index';

//# sourceMappingURL=ngx-json-viewer.d.ts.map