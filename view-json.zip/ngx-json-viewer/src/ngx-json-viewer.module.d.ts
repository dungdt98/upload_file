import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './ngx-json-viewer/ngx-json-viewer.component';
import * as ɵngcc2 from '@angular/common';
export declare class NgxJsonViewerModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<NgxJsonViewerModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<NgxJsonViewerModule, [typeof ɵngcc1.NgxJsonViewerComponent], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgxJsonViewerComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<NgxJsonViewerModule>;
}

//# sourceMappingURL=ngx-json-viewer.module.d.ts.map