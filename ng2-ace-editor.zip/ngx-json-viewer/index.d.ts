export { NgxJsonViewerModule } from "./src/ngx-json-viewer.module";
export { NgxJsonViewerComponent } from "./src/ngx-json-viewer/ngx-json-viewer.component";
