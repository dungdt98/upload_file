import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export interface Segment {
    key: string;
    value: any;
    type: undefined | string;
    description: string;
    expanded: boolean;
}
export declare class NgxJsonViewerComponent implements OnChanges {
    json: any;
    expanded: boolean;
    depth: number;
    _currentDepth: number;
    segments: Segment[];
    ngOnChanges(): void;
    isExpandable(segment: Segment): boolean;
    toggle(segment: Segment): void;
    private parseKeyValue;
    private isExpanded;
    private decycle;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxJsonViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxJsonViewerComponent, "ngx-json-viewer", never, { "json": "json"; "expanded": "expanded"; "depth": "depth"; "_currentDepth": "_currentDepth"; }, {}, never, never, false>;
}
