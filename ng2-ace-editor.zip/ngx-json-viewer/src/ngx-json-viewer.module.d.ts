import * as i0 from "@angular/core";
import * as i1 from "./ngx-json-viewer/ngx-json-viewer.component";
import * as i2 from "@angular/common";
export declare class NgxJsonViewerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxJsonViewerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgxJsonViewerModule, [typeof i1.NgxJsonViewerComponent], [typeof i2.CommonModule], [typeof i1.NgxJsonViewerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgxJsonViewerModule>;
}
