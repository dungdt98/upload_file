export declare class AceEditorModule {
}
