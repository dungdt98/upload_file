export { AceEditorDirective } from './src/directive';
export { AceEditorComponent } from './src/component';
export { AceEditorModule } from './src/module';
