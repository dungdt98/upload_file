import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './plotly.component';
import * as ɵngcc2 from '@angular/common';
export declare class PlotlySharedModule {
    constructor();
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<PlotlySharedModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<PlotlySharedModule, [typeof ɵngcc1.PlotlyComponent], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.PlotlyComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<PlotlySharedModule>;
}

//# sourceMappingURL=plotly-shared.module.d.ts.map