/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';

//# sourceMappingURL=angular-plotly.js.d.ts.map