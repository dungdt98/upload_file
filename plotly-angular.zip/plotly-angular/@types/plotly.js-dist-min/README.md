# Installation
> `npm install --save @types/plotly.js-dist-min`

# Summary
This package contains type definitions for plotly.js-dist-min (https://github.com/plotly/plotly.js#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/plotly.js-dist-min.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/plotly.js-dist-min/index.d.ts)
````ts
import * as Plotly from "plotly.js";

export = Plotly;

````

### Additional Details
 * Last updated: Tue, 07 Nov 2023 09:09:39 GMT
 * Dependencies: [@types/plotly.js](https://npmjs.com/package/@types/plotly.js)

# Credits
These definitions were written by [André Farzat](https://github.com/andrefarzat).
