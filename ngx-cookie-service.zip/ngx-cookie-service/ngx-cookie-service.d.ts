/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-cookie-service" />
export * from './public-api';
